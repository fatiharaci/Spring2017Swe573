from django.views.generic.base import View

__all__ = ['View']
